package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.pojo.HealthJkpg;
import com.ayu.healthmanagement.service.HealthJkpgService;
import com.ayu.healthmanagement.utils.ExcelUtil;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/jkpg")
public class HealthJkpgController {


    @Autowired
    private HealthJkpgService service;

    @RequestMapping("/list")
    public Result list(String name) {
        LambdaQueryWrapper<HealthJkpg> qw = new LambdaQueryWrapper<>();
        qw.like(HealthJkpg::getName, name);
        List<HealthJkpg> list = service.list(qw);
        return Result.success(list);
    }

    @RequestMapping("/add")
    public Result add(@RequestBody HealthJkpg healthJkpg) {
        service.save(healthJkpg);
        return Result.success();
    }

    @RequestMapping("/delete")
    public Result delete(Integer id) {
        service.removeById(id);
        return Result.success();
    }

    @RequestMapping("/export")
    public void export(HttpServletResponse response) {
        List<HealthJkpg> list = service.list();
        ExcelUtil.download(response,list, HealthJkpg.class);
    }
}
