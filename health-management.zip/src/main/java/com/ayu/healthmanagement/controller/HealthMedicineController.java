package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthGroup;
import com.ayu.healthmanagement.pojo.HealthMedicine;
import com.ayu.healthmanagement.service.HealthMedicineService;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("medicine")
public class HealthMedicineController {

    @Autowired
    private HealthMedicineService healthMedicineService;

    @GetMapping("/getHealthMedicineByArchiveNumber")
    public Result getHealthMedicineByArchiveNumber(String archiveNumber){
        return healthMedicineService.getHealthMedicineByArchiveNumber(archiveNumber);
    }

    @GetMapping("/getHealthMedicine")
    public Result getHealthMedicine(String medicineName, Integer pageNum, Integer pageSize){
        return healthMedicineService.getHealthMedicine(medicineName,pageNum,pageSize);
    }

    @GetMapping("/delHealthMedicine")
    public Result delHealthMedicine(Integer id){
        return healthMedicineService.delHealthMedicine(id);
    }

    @PostMapping("/updateHealthMedicine")
    public Result updateHealthMedicine(@RequestBody HealthMedicine healthMedicine){
        return healthMedicineService.updateHealthMedicine(healthMedicine);
    }

    @PostMapping("/insertHealthMedicine")
    public Result insertHealthMedicine(@RequestBody HealthMedicine healthMedicine){
        return healthMedicineService.insertHealthMedicine(healthMedicine);
    }
}
