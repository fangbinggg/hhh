package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthTaocan;
import com.ayu.healthmanagement.service.HealthTaocanService;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/taocan")
public class HealthTaocanController {

    @Autowired
    private HealthTaocanService service;

    /**
     * @param taocanName
     * @return
     */
    @RequestMapping("/list")
    public Result list(String taocanName) {
        LambdaQueryWrapper<HealthTaocan> taocanQuery = new LambdaQueryWrapper<>();
        taocanQuery.like(HealthTaocan::getTaocanName, taocanName);
        List<HealthTaocan> taocanList = service.list(taocanQuery);
        return Result.success(taocanList);
    }
}
