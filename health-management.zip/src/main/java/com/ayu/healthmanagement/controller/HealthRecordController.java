package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthDiet;
import com.ayu.healthmanagement.pojo.HealthRecord;
import com.ayu.healthmanagement.service.HealthRecordService;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.crypto.Data;
import java.util.Date;

@RestController
@RequestMapping("record")
public class HealthRecordController {

    @Autowired
    private HealthRecordService healthRecordService;

    @GetMapping("/getHealthRecords")
    public Result getHealthRecords(String beginTime, String endTime, Integer pageNum, Integer pageSize){
//        System.out.println(beginTime+"0=0=0="+endTime);
//        return Result.success();
        return healthRecordService.getHealthRecords(beginTime,endTime,pageNum,pageSize);
    }

    @GetMapping("/delHealthRecord")
    public Result delHealthRecord(Integer id){
        return healthRecordService.delHealthRecord(id);
    }

    @PostMapping("/insertHealthRecord")
    public Result insertHealthRecord(@RequestBody HealthRecord healthMedicine){
        return healthRecordService.insertHealthRecord(healthMedicine);
    }
}
