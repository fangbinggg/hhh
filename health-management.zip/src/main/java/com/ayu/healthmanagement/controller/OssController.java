package com.ayu.healthmanagement.controller;


import com.ayu.healthmanagement.utils.OssUtils;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class OssController {
    @PostMapping("/upload")
    public Result upload(@RequestParam(value = "file") MultipartFile file) throws IOException {
        System.out.println("文件上传到这了。。。");
        //获取文件名
        String filename = file.getOriginalFilename();
        System.out.println("fileName=>"+filename);
        //调用ossUtil上传图文件
        String fileUrl = OssUtils.uploadFile(file.getInputStream(), filename);
        return Result.success(fileUrl);
    }

    @GetMapping("/deleteFile")
    public void deleteFile(@RequestParam("imgUrl") String imgUrl) {
        //截取文件名
        String[] split = imgUrl.split("/");
//        System.out.println(Arrays.toString(split));
        imgUrl=split[3]+"/"+split[4];
        //调用ossUtil上传图文件
        OssUtils.deleteFile(imgUrl);
    }
}
