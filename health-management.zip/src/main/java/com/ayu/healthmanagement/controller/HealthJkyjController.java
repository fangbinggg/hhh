package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthJkyj;
import com.ayu.healthmanagement.service.HealthJkyjService;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/jkyj")
public class HealthJkyjController {

    @Autowired
    private HealthJkyjService service;

    @RequestMapping("/list")
    public Result list(String name) {
        LambdaQueryWrapper<HealthJkyj> qw = new LambdaQueryWrapper<>();
        qw.like(HealthJkyj::getName, name);
        return Result.success(service.list(qw));
    }

    @RequestMapping("/add")
    public Result add(@RequestBody HealthJkyj healthJkyj) {
        healthJkyj.setEvaluationTime(new Date());
        service.save(healthJkyj);
        return Result.success();
    }

    @RequestMapping("/delete")
    public Result delete(Integer id) {
        service.removeById(id);
        return Result.success();
    }

}
