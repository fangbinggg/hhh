package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.mapper.HealthDietMapper;
import com.ayu.healthmanagement.pojo.HealthDiet;
import com.ayu.healthmanagement.pojo.HealthMedicine;
import com.ayu.healthmanagement.service.HealthDietService;
import com.ayu.healthmanagement.service.HealthMedicineService;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("diet")
public class HealthDietController {

    @Autowired
    private HealthDietService healthDietService;

    @GetMapping("/getHealthDietsByArchiveNumber")
    public Result getHealthDietsByArchiveNumber(String archiveNumber){
        return healthDietService.getHealthDietsByArchiveNumber(archiveNumber);
    }

    @GetMapping("/getHealthDiets")
    public Result getHealthDiets(String dietName,Integer pageNum,Integer pageSize){
        return healthDietService.getHealthDiets(dietName,pageNum,pageSize);
    }

    @GetMapping("/delHealthDiet")
    public Result delHealthDiet(Integer id){
        return healthDietService.delHealthDiet(id);
    }

    @PostMapping("/updateHealthDiet")
    public Result updateHealthDiet(@RequestBody HealthDiet healthMedicine){
        return healthDietService.updateHealthDiet(healthMedicine);
    }

    @PostMapping("/insertHealthDiet")
    public Result insertHealthDiet(@RequestBody HealthDiet healthMedicine){
        return healthDietService.insertHealthDiet(healthMedicine);
    }
}
