package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.service.InitDataService;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("init")
public class InitDataController {

    @Autowired
    private InitDataService initDataService;

    @GetMapping("/getInitByArchiveNumber")
    public Result getInitByArchiveNumber(String archiveNumber){
        return initDataService.getInitByArchiveNumber(archiveNumber);
    }

    @GetMapping("/getIllness")
    public Result getIllness(){
        return initDataService.getIllness();
    }

    @GetMapping("/getInitAverageValue")
    public Result getInitAverageValue(HttpServletRequest request){
        return initDataService.getInitAverageValue(request);
    }
}
