package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.dto.UserDto;
import com.ayu.healthmanagement.pojo.HealthUser;
import com.ayu.healthmanagement.service.HealthUserService;
import com.ayu.healthmanagement.utils.JwtUtils;
import com.ayu.healthmanagement.utils.Result;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("user")
public class HealthUserController {

    @Autowired
    private HealthUserService healthUserService;

    @PostMapping("/import")
    public Result importUsers(@RequestParam("file") MultipartFile file) {
        return Result.success(healthUserService.importUsers(file));
    }

    @PostMapping("/exportUser")
    public void exportUser(@RequestBody Long[] ids, HttpServletResponse response){
        healthUserService.downLoad(ids,response);
    }

    @GetMapping("/getUserByUserPhone")
    public Result getUserByUserPhone(String userPhone){
        return healthUserService.getUserByUserPhone(userPhone);
    }

    @GetMapping("/updateImgUrl")
    public Result updateImgUrl(Integer id,String imgUrl){
        return healthUserService.updateImgUrl(id,imgUrl);
    }

    @GetMapping("/updatePassword")
    public Result updatePassword(HttpServletRequest request,String oldPassword,String newPassword){
        String token = request.getHeader("token");
        int userId = Integer.parseInt(JwtUtils.getId(token));
        return healthUserService.updatePassword(userId,oldPassword,newPassword);
    }

    @GetMapping("/resetPassword")
    public Result resetPassword(Integer userId,String password){
        return healthUserService.resetPassword(userId,password);
    }

    @PostMapping("/delUser")
    public Result delUser(@RequestBody Integer[] ids){
        return healthUserService.delUser(ids);
    }

    @PostMapping("/updateUser")
    public Result updateUser(@RequestBody HealthUser healthUser){
        return healthUserService.updateUser(healthUser);
    }

    @PostMapping("/getSysUserList")
    public Result getSysUserList(@RequestBody UserDto userDto){
        return healthUserService.getSysUserList(userDto);
    }

    @GetMapping("/getUserById")
    public Result getUserById(HttpServletRequest request){
        String token = request.getHeader("token");
        Integer userId = Integer.parseInt(JwtUtils.getId(token));
        return healthUserService.getUserById(userId);
    }

    @PostMapping("/login")
    public Result login(@RequestBody HealthUser healthUser, HttpServletRequest request){
        return healthUserService.login(healthUser);
    }

    @PostMapping("/register")
    public Result register(@RequestBody HealthUser healthUser){
        return healthUserService.register(healthUser);
    }
}
