package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.service.HealthMenuService;
import com.ayu.healthmanagement.utils.JwtUtils;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class HealthMenuController {

    @Autowired
    private HealthMenuService healthMenuService;

    @GetMapping("/getMenus")
    public Result getMenus(HttpServletRequest request){
        String token = request.getHeader("token");
        Integer userId = Integer.valueOf(JwtUtils.getId(token));
        return Result.success(healthMenuService.getMenus(userId));
    }
}
