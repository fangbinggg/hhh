package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthAppointment;
import com.ayu.healthmanagement.service.HealthAppointmentService;
import com.ayu.healthmanagement.utils.JwtUtils;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("appointment")
public class HealthAppointmentController {

    @Autowired
    private HealthAppointmentService healthAppointmentService;

    @GetMapping("/noCheckAppointment")
    public Result noCheckAppointment(Integer id){
        return healthAppointmentService.noCheckAppointment(id);
    }

    @GetMapping("/checkAppointment")
    public Result checkAppointment(Integer id){
        return healthAppointmentService.checkAppointment(id);
    }

    @GetMapping("/delAppointment")
    public Result delAppointment(Integer id){
        return healthAppointmentService.delAppointment(id);
    }

    @PostMapping("/insertAppointment")
    public Result insertAppointment(@RequestBody HealthAppointment healthAppointment, HttpServletRequest request){
        String token = request.getHeader("token");
        Integer userId = Integer.valueOf(JwtUtils.getId(token));
        healthAppointment.setUserId(userId);
        return healthAppointmentService.insertAppointment(healthAppointment);
    }

    @GetMapping("/getAppointmentList")
    public Result getAppointmentList(String userPhone,Integer pageNum,Integer pageSize,HttpServletRequest request){
        String token = request.getHeader("token");
        Integer userId = Integer.parseInt(JwtUtils.getId(token));
        return healthAppointmentService.getAppointmentList(userId,userPhone,pageNum,pageSize);
    }
}
