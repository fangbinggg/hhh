package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.pojo.HealthGroup;
import com.ayu.healthmanagement.service.HealthGroupService;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("group")
public class HealthGroupController {

    @Autowired
    private HealthGroupService healthGroupService;

    @GetMapping("/delHealthGroup")
    public Result delHealthGroup(Integer id){
        return healthGroupService.delHealthGroup(id);
    }

    @GetMapping("/getHealthGroups")
    public Result getHealthGroups(String groupName){
        return healthGroupService.getHealthGroups(groupName);
    }

    @PostMapping("/updateHealthGroup")
    public Result updateHealthGroup(@RequestBody HealthGroup healthGroup){
        return healthGroupService.updateHealthGroup(healthGroup);
    }

    @PostMapping("/insertHealthGroup")
    public Result insertHealthGroup(@RequestBody HealthGroup healthGroup){
        return healthGroupService.insertHealthGroup(healthGroup);
    }
}
