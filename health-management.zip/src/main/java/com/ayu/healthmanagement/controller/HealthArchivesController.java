package com.ayu.healthmanagement.controller;

import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.service.HealthArchivesService;
import com.ayu.healthmanagement.utils.JwtUtils;
import com.ayu.healthmanagement.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("archives")
public class HealthArchivesController {
    @Autowired
    private HealthArchivesService healthArchivesService;

    @PostMapping("/exportUser")
    public void exportUser(@RequestBody Long[] ids, HttpServletResponse response){
        healthArchivesService.downLoad(ids,response);
    }

    @GetMapping("/getArchivesByNumber")
    public Result getArchivesByNumber(String archiveNumber){
        return healthArchivesService.getArchivesByNumber(archiveNumber);
    }

    @GetMapping("/getArchivesByUserId")
    public Result getArchivesByUserId(HttpServletRequest request){
        String token = request.getHeader("token");
        Integer userId = Integer.valueOf(JwtUtils.getId(token));
        return healthArchivesService.getArchivesByUserId(userId);
    }

    @GetMapping("/delArchives")
    public Result delArchives(Integer id){
        return healthArchivesService.delArchives(id);
    }

    @GetMapping("/getArchives")
    public Result getArchives(Integer groupId,String userPhone,String idCard,Integer pageNum,Integer pageSize){
        return healthArchivesService.getArchives(groupId,userPhone,idCard,pageNum,pageSize);
    }

    @PostMapping("/updateArchives")
    public Result updateArchives(@RequestBody HealthArchives healthArchives){
        return healthArchivesService.updateArchives(healthArchives);
    }

    @PostMapping("/insertArchives")
    public Result insertArchives(@RequestBody HealthArchives healthArchives){
        return healthArchivesService.insertArchives(healthArchives);
    }
}
