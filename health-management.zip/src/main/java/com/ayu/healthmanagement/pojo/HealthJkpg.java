package com.ayu.healthmanagement.pojo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@TableName("health_jkpg")
@Data
public class HealthJkpg {

    @TableId(type = IdType.AUTO)
    @ExcelIgnore
    private Integer id;

    @ExcelProperty("姓名")
    private String name;

    @ExcelProperty("血压")
    private String bloodPressure;

    @ExcelProperty("心率")
    private String heartRate;

    @ExcelProperty("饱和度")
    private String saturation;

    @ExcelProperty("体重")
    private String weight;

    @ExcelProperty("健康等级")
    private String grade;

    @ExcelProperty("评估时间")
    private Date evaluationTime;
}
