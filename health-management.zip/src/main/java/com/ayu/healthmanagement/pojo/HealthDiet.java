package com.ayu.healthmanagement.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName health_diet
 */
@TableName(value ="health_diet")
@Data
public class HealthDiet implements Serializable {
    /**
     * 饮食方案主键
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 方案名
     */
    private String dietName;

    /**
     * 方案内容
     */
    private String dietContent;

    /**
     * 档案编号
     */
    private String archiveNumber;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HealthDiet other = (HealthDiet) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getDietName() == null ? other.getDietName() == null : this.getDietName().equals(other.getDietName()))
            && (this.getDietContent() == null ? other.getDietContent() == null : this.getDietContent().equals(other.getDietContent()))
            && (this.getArchiveNumber() == null ? other.getArchiveNumber() == null : this.getArchiveNumber().equals(other.getArchiveNumber()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getDietName() == null) ? 0 : getDietName().hashCode());
        result = prime * result + ((getDietContent() == null) ? 0 : getDietContent().hashCode());
        result = prime * result + ((getArchiveNumber() == null) ? 0 : getArchiveNumber().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", dietName=").append(dietName);
        sb.append(", dietContent=").append(dietContent);
        sb.append(", archiveNumber=").append(archiveNumber);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}