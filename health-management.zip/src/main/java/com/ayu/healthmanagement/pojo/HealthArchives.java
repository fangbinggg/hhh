package com.ayu.healthmanagement.pojo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName health_archives
 */
@TableName(value ="health_archives")
@Data
public class HealthArchives implements Serializable {
    /**
     * 档案主键
     */
    @TableId(type = IdType.AUTO)
    @ExcelProperty("编号")
    private Integer id;

    /**
     * 用户主键
     */
    @ExcelIgnore
    private Integer userId;

    /**
     * 年龄
     */
    @ExcelProperty("年龄")
    private Integer age;

    /**
     * 性别（使用ENUM类型限制为'M男'、'F女'或'O其他'）
     */
    @ExcelProperty("性别")
    private String gender;

    /**
     * 身高
     */
    @ExcelProperty("身高")
    private Integer height;

    /**
     * 体重
     */
    @ExcelProperty("体重")
    private Integer weight;

    /**
     * 血型
     */
    @ExcelProperty("血型")
    private String bloodType;

    /**
     * 过敏情况
     */
    @ExcelProperty("过敏情况")
    private String allergies;

    /**
     * 病史
     */
    @ExcelProperty("病史")
    private String medicalHistory;

    /**
     * 患者正在服用药物
     */
    @ExcelProperty("患者正在服用药物")
    private String medication;

    /**
     * 档案创建时间
     */
    @ExcelProperty("档案创建时间")
    private Date createTime;

    /**
     * 档案更新时间
     */
    @ExcelProperty("档案更新时间")
    private Date updateTime;

    /**
     * 档案档案编号（有系统生成）
     */
    @ExcelProperty("档案档案编号")
    private String archiveNumber;

    /**
     * 身份证号
     */
    @ExcelProperty("身份证号")
    private String idCard;

    /**
     * 分组id
     */
    @ExcelIgnore
    private Integer groupId;

    /**
     * 血压
     */
    @ExcelProperty("血压")
    private String bloodPressure;

    /**
     * 血糖
     */
    @ExcelProperty("血糖")
    private String bloodSugar;

    /**
     * 心率
     */
    @ExcelProperty("心率")
    private String heartRate;

    /**
     * 肝（0正常1异常）
     */
    @ExcelProperty("肝（是否正常）")
    private String liver;

    /**
     * 肾（0正常1异常）
     */
    @ExcelProperty("肾（是否正常）")
    private String kidney;

    /**
     * 胆（0正常1异常）
     */
    @ExcelProperty("胆（是否正常）")
    private String gallbladder;

    /**
     * 脾（0正常1异常）
     */
    @ExcelProperty("脾（是否正常）")
    private String spleen;

    /**
     * 胃（0正常1异常）
     */
    @ExcelProperty("胃（是否正常）")
    private String stomach;

    /**
     * 嗅觉（0正常1异常）
     */
    @ExcelProperty("嗅觉（是否正常）")
    private String smell;

    /**
     * 味觉（正常1异常）
     */
    @ExcelProperty("味觉（是否正常）")
    private String gustatorysensation;

    /**
     * 听觉
     */
    @ExcelProperty("听觉（是否正常）")
    private String hearing;

    /**
     * 触觉
     */
    @ExcelProperty("触觉（是否正常）")
    private String tactilesensation;

    /**
     * 视觉
     */
    @ExcelProperty("视觉（是否正常）")
    private String vision;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HealthArchives other = (HealthArchives) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getUserId() == null ? other.getUserId() == null : this.getUserId().equals(other.getUserId()))
            && (this.getAge() == null ? other.getAge() == null : this.getAge().equals(other.getAge()))
            && (this.getGender() == null ? other.getGender() == null : this.getGender().equals(other.getGender()))
            && (this.getHeight() == null ? other.getHeight() == null : this.getHeight().equals(other.getHeight()))
            && (this.getWeight() == null ? other.getWeight() == null : this.getWeight().equals(other.getWeight()))
            && (this.getBloodType() == null ? other.getBloodType() == null : this.getBloodType().equals(other.getBloodType()))
            && (this.getAllergies() == null ? other.getAllergies() == null : this.getAllergies().equals(other.getAllergies()))
            && (this.getMedicalHistory() == null ? other.getMedicalHistory() == null : this.getMedicalHistory().equals(other.getMedicalHistory()))
            && (this.getMedication() == null ? other.getMedication() == null : this.getMedication().equals(other.getMedication()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getArchiveNumber() == null ? other.getArchiveNumber() == null : this.getArchiveNumber().equals(other.getArchiveNumber()))
            && (this.getIdCard() == null ? other.getIdCard() == null : this.getIdCard().equals(other.getIdCard()))
            && (this.getGroupId() == null ? other.getGroupId() == null : this.getGroupId().equals(other.getGroupId()))
            && (this.getBloodPressure() == null ? other.getBloodPressure() == null : this.getBloodPressure().equals(other.getBloodPressure()))
            && (this.getBloodSugar() == null ? other.getBloodSugar() == null : this.getBloodSugar().equals(other.getBloodSugar()))
            && (this.getHeartRate() == null ? other.getHeartRate() == null : this.getHeartRate().equals(other.getHeartRate()))
            && (this.getLiver() == null ? other.getLiver() == null : this.getLiver().equals(other.getLiver()))
            && (this.getKidney() == null ? other.getKidney() == null : this.getKidney().equals(other.getKidney()))
            && (this.getGallbladder() == null ? other.getGallbladder() == null : this.getGallbladder().equals(other.getGallbladder()))
            && (this.getSpleen() == null ? other.getSpleen() == null : this.getSpleen().equals(other.getSpleen()))
            && (this.getStomach() == null ? other.getStomach() == null : this.getStomach().equals(other.getStomach()))
            && (this.getSmell() == null ? other.getSmell() == null : this.getSmell().equals(other.getSmell()))
            && (this.getGustatorysensation() == null ? other.getGustatorysensation() == null : this.getGustatorysensation().equals(other.getGustatorysensation()))
            && (this.getHearing() == null ? other.getHearing() == null : this.getHearing().equals(other.getHearing()))
            && (this.getTactilesensation() == null ? other.getTactilesensation() == null : this.getTactilesensation().equals(other.getTactilesensation()))
            && (this.getVision() == null ? other.getVision() == null : this.getVision().equals(other.getVision()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getUserId() == null) ? 0 : getUserId().hashCode());
        result = prime * result + ((getAge() == null) ? 0 : getAge().hashCode());
        result = prime * result + ((getGender() == null) ? 0 : getGender().hashCode());
        result = prime * result + ((getHeight() == null) ? 0 : getHeight().hashCode());
        result = prime * result + ((getWeight() == null) ? 0 : getWeight().hashCode());
        result = prime * result + ((getBloodType() == null) ? 0 : getBloodType().hashCode());
        result = prime * result + ((getAllergies() == null) ? 0 : getAllergies().hashCode());
        result = prime * result + ((getMedicalHistory() == null) ? 0 : getMedicalHistory().hashCode());
        result = prime * result + ((getMedication() == null) ? 0 : getMedication().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getArchiveNumber() == null) ? 0 : getArchiveNumber().hashCode());
        result = prime * result + ((getIdCard() == null) ? 0 : getIdCard().hashCode());
        result = prime * result + ((getGroupId() == null) ? 0 : getGroupId().hashCode());
        result = prime * result + ((getBloodPressure() == null) ? 0 : getBloodPressure().hashCode());
        result = prime * result + ((getBloodSugar() == null) ? 0 : getBloodSugar().hashCode());
        result = prime * result + ((getHeartRate() == null) ? 0 : getHeartRate().hashCode());
        result = prime * result + ((getLiver() == null) ? 0 : getLiver().hashCode());
        result = prime * result + ((getKidney() == null) ? 0 : getKidney().hashCode());
        result = prime * result + ((getGallbladder() == null) ? 0 : getGallbladder().hashCode());
        result = prime * result + ((getSpleen() == null) ? 0 : getSpleen().hashCode());
        result = prime * result + ((getStomach() == null) ? 0 : getStomach().hashCode());
        result = prime * result + ((getSmell() == null) ? 0 : getSmell().hashCode());
        result = prime * result + ((getGustatorysensation() == null) ? 0 : getGustatorysensation().hashCode());
        result = prime * result + ((getHearing() == null) ? 0 : getHearing().hashCode());
        result = prime * result + ((getTactilesensation() == null) ? 0 : getTactilesensation().hashCode());
        result = prime * result + ((getVision() == null) ? 0 : getVision().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", age=").append(age);
        sb.append(", gender=").append(gender);
        sb.append(", height=").append(height);
        sb.append(", weight=").append(weight);
        sb.append(", bloodType=").append(bloodType);
        sb.append(", allergies=").append(allergies);
        sb.append(", medicalHistory=").append(medicalHistory);
        sb.append(", medication=").append(medication);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", archiveNumber=").append(archiveNumber);
        sb.append(", idCard=").append(idCard);
        sb.append(", groupId=").append(groupId);
        sb.append(", bloodPressure=").append(bloodPressure);
        sb.append(", bloodSugar=").append(bloodSugar);
        sb.append(", heartRate=").append(heartRate);
        sb.append(", liver=").append(liver);
        sb.append(", kidney=").append(kidney);
        sb.append(", gallbladder=").append(gallbladder);
        sb.append(", spleen=").append(spleen);
        sb.append(", stomach=").append(stomach);
        sb.append(", smell=").append(smell);
        sb.append(", gustatorysensation=").append(gustatorysensation);
        sb.append(", hearing=").append(hearing);
        sb.append(", tactilesensation=").append(tactilesensation);
        sb.append(", vision=").append(vision);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}