package com.ayu.healthmanagement.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName health_record
 */
@TableName(value ="health_record")
@Data
public class HealthRecord implements Serializable {
    /**
     * 健康日志表
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 记录时间
     */
    private Date time;

    /**
     * 心情
     */
    private String mood;

    /**
     * 饮食情况
     */
    private String diet;

    /**
     * 睡眠情况
     */
    private String sleep;

    /**
     * 身高
     */
    private Integer height;

    /**
     * 体重
     */
    private Integer weight;

    /**
     * 血压
     */
    private String bloodPressure;

    /**
     * 心率
     */
    private String heartRate;

    /**
     * 血糖
     */
    private String bloodSugar;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HealthRecord other = (HealthRecord) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getTime() == null ? other.getTime() == null : this.getTime().equals(other.getTime()))
            && (this.getMood() == null ? other.getMood() == null : this.getMood().equals(other.getMood()))
            && (this.getDiet() == null ? other.getDiet() == null : this.getDiet().equals(other.getDiet()))
            && (this.getSleep() == null ? other.getSleep() == null : this.getSleep().equals(other.getSleep()))
            && (this.getHeight() == null ? other.getHeight() == null : this.getHeight().equals(other.getHeight()))
            && (this.getWeight() == null ? other.getWeight() == null : this.getWeight().equals(other.getWeight()))
            && (this.getBloodPressure() == null ? other.getBloodPressure() == null : this.getBloodPressure().equals(other.getBloodPressure()))
            && (this.getHeartRate() == null ? other.getHeartRate() == null : this.getHeartRate().equals(other.getHeartRate()))
            && (this.getBloodSugar() == null ? other.getBloodSugar() == null : this.getBloodSugar().equals(other.getBloodSugar()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getTime() == null) ? 0 : getTime().hashCode());
        result = prime * result + ((getMood() == null) ? 0 : getMood().hashCode());
        result = prime * result + ((getDiet() == null) ? 0 : getDiet().hashCode());
        result = prime * result + ((getSleep() == null) ? 0 : getSleep().hashCode());
        result = prime * result + ((getHeight() == null) ? 0 : getHeight().hashCode());
        result = prime * result + ((getWeight() == null) ? 0 : getWeight().hashCode());
        result = prime * result + ((getBloodPressure() == null) ? 0 : getBloodPressure().hashCode());
        result = prime * result + ((getHeartRate() == null) ? 0 : getHeartRate().hashCode());
        result = prime * result + ((getBloodSugar() == null) ? 0 : getBloodSugar().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", time=").append(time);
        sb.append(", mood=").append(mood);
        sb.append(", diet=").append(diet);
        sb.append(", sleep=").append(sleep);
        sb.append(", height=").append(height);
        sb.append(", weight=").append(weight);
        sb.append(", bloodPressure=").append(bloodPressure);
        sb.append(", heartRate=").append(heartRate);
        sb.append(", bloodSugar=").append(bloodSugar);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}