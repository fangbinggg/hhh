package com.ayu.healthmanagement.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName health_medicine
 */
@TableName(value ="health_medicine")
@Data
public class HealthMedicine implements Serializable {
    /**
     * 药物方案主键
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 药物方案名
     */
    private String medicineName;

    /**
     * 药物方案内容
     */
    private String medicineContent;

    /**
     * 档案编号
     */
    private String archiveNumber;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date updateTime;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HealthMedicine other = (HealthMedicine) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getMedicineName() == null ? other.getMedicineName() == null : this.getMedicineName().equals(other.getMedicineName()))
            && (this.getMedicineContent() == null ? other.getMedicineContent() == null : this.getMedicineContent().equals(other.getMedicineContent()))
            && (this.getArchiveNumber() == null ? other.getArchiveNumber() == null : this.getArchiveNumber().equals(other.getArchiveNumber()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getMedicineName() == null) ? 0 : getMedicineName().hashCode());
        result = prime * result + ((getMedicineContent() == null) ? 0 : getMedicineContent().hashCode());
        result = prime * result + ((getArchiveNumber() == null) ? 0 : getArchiveNumber().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", medicineName=").append(medicineName);
        sb.append(", medicineContent=").append(medicineContent);
        sb.append(", archiveNumber=").append(archiveNumber);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}