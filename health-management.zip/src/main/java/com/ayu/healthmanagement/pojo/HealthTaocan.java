package com.ayu.healthmanagement.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("health_taocan")
@Data
public class HealthTaocan {
    @TableId(type = IdType.AUTO)
    private Integer id;

    private String taocanName;

    private String hospital;

    private String address;

    private String roomName;

    private double price;

    private String cover;
}
