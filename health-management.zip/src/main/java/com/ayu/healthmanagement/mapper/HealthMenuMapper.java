package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthMenu
 */
public interface HealthMenuMapper extends BaseMapper<HealthMenu> {

}




