package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthMedicine;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.awt.*;
import java.util.List;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthMedicine
 */
public interface HealthMedicineMapper extends BaseMapper<HealthMedicine> {

    List<HealthMedicine> getHealthMedicine(String medicineName, Integer index, Integer pageSize);
}




