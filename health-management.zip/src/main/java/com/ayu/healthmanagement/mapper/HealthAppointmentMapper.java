package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthAppointment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthAppointment
 */
public interface HealthAppointmentMapper extends BaseMapper<HealthAppointment> {

    List<HealthAppointment> getAppointmentList(Integer userId,String userPhone, Integer index, Integer pageSize);
}




