package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.dto.UserDto;
import com.ayu.healthmanagement.pojo.HealthUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthUser
 */
public interface HealthUserMapper extends BaseMapper<HealthUser> {

    List<HealthUser> getSysUserList(@Param("user") UserDto userDto,@Param("index") Integer index, @Param("pageSize")Integer pageSize);
}




