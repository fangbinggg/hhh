package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthDiet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthDiet
 */
public interface HealthDietMapper extends BaseMapper<HealthDiet> {

    List<HealthDiet> getHealthDiets(String dietName, Integer index, Integer pageSize);
}




