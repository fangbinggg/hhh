package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthJkpg;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface HealthJkpgMapper extends BaseMapper<HealthJkpg> {
}
