package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthJkyj;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface HealthJkyjMapper extends BaseMapper<HealthJkyj> {
}
