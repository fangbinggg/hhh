package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthGroup;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthGroup
 */
public interface HealthGroupMapper extends BaseMapper<HealthGroup> {

}




