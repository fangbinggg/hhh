package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthTaocan;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface HealthTaocanMapper extends BaseMapper<HealthTaocan> {
}
