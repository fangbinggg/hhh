package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.pojo.HealthRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthRecord
 */
public interface HealthRecordMapper extends BaseMapper<HealthRecord> {

    List<HealthRecord> getHealthRecords(String beginTime, String endTime, Integer index, Integer pageSize);
}




