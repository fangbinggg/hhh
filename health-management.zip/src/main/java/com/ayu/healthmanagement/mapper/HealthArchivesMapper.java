package com.ayu.healthmanagement.mapper;

import com.ayu.healthmanagement.dto.ArchivesAndUserDto;
import com.ayu.healthmanagement.pojo.HealthArchives;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * @Entity com.ayu.healthmanagement.pojo.HealthArchives
 */
public interface HealthArchivesMapper extends BaseMapper<HealthArchives> {

    List<ArchivesAndUserDto> getArchives(Integer groupId,String userPhone, String idCard, Integer index, Integer pageSize);

    ArchivesAndUserDto getArchivesByNumber(String archiveNumber);

    double getAgeAverageValue();

    double getHeightAverageValue();

    double getWeightAverageValue();

    double getBloodPressureAverageValue();

    double getBloodSugarAverageValue();

    double getHeartRateAverageValue();

    ArchivesAndUserDto getArchivesByUserId(Integer userId);
}




