package com.ayu.healthmanagement.dto;

import lombok.Data;

@Data
public class UserDto {
    private Integer pageNum;
    private Integer pageSize;
    private String userName;
    private String userPhone;
}
