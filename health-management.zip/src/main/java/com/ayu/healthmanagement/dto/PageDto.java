package com.ayu.healthmanagement.dto;

import lombok.Data;

@Data
public class PageDto {
    private Integer pageNum;
    private Integer size;
    private Integer total;
    private Object children;

    public PageDto(Integer pageNum, Integer size, Integer total, Object children) {
        this.pageNum = pageNum;
        this.size = size;
        this.total = total;
        this.children = children;
    }

    public Object getChildren() {
        return children;
    }

    public void setChildren(Object children) {
        this.children = children;
    }
}
