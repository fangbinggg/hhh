package com.ayu.healthmanagement.dto;

import com.ayu.healthmanagement.pojo.HealthArchives;
import lombok.Data;

@Data
public class ArchivesAndUserDto extends HealthArchives {
    /**
     * 用户名
     */
    private String userName;

    /**
     * 手机号
     */
    private String userPhone;
}
