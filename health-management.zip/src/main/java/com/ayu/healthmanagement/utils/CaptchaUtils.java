package com.ayu.healthmanagement.utils;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.LineCaptcha;
import com.ayu.healthmanagement.captcha.Captcha;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class CaptchaUtils {

    // 生成验证码
    public LineCaptcha createCode() throws IOException {
        // 创建验证码图片
        LineCaptcha captcha = CaptchaUtil.createLineCaptcha(40, 30, 4,8);
        // 生成验证码
//        String code = captcha.getCode();
        return captcha;
    }

    // 校验验证码
    public boolean checkCode(String userCode, Captcha cap) {
        // 验证码为空
        if (cap == null || cap.isExpired()) {
            return false;
        }
        // 验证码不正确
        if (!cap.getCode().equalsIgnoreCase(userCode.trim())) {
            return false;
        }
        // 通过验证
        return true;
    }

}