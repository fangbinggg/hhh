package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.dto.PageDto;
import com.ayu.healthmanagement.mapper.HealthMenuMapper;
import com.ayu.healthmanagement.utils.Result;
import com.ayu.healthmanagement.utils.ResultCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ayu.healthmanagement.pojo.HealthMedicine;
import com.ayu.healthmanagement.service.HealthMedicineService;
import com.ayu.healthmanagement.mapper.HealthMedicineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 */
@Service
public class HealthMedicineServiceImpl extends ServiceImpl<HealthMedicineMapper, HealthMedicine>
    implements HealthMedicineService{

    @Autowired
    private HealthMedicineMapper healthMedicineMapper;

    @Override
    public Result getHealthMedicine(String medicineName, Integer pageNum, Integer pageSize) {
        List<HealthMedicine> healthMedicine = healthMedicineMapper.getHealthMedicine(medicineName, (pageNum - 1) * pageSize, pageSize);
        int size = healthMedicineMapper.getHealthMedicine(medicineName, null, null).size();
        return Result.success(new PageDto(pageNum,pageSize,size,healthMedicine));
    }

    @Override
    public Result delHealthMedicine(Integer id) {
        return Result.success(healthMedicineMapper.deleteById(id));
    }

    @Override
    public Result updateHealthMedicine(HealthMedicine healthMedicine) {
        return Result.success(healthMedicineMapper.updateById(healthMedicine));
    }

    @Override
    public Result insertHealthMedicine(HealthMedicine healthMedicine) {
        if (healthMedicineMapper.selectOne(new QueryWrapper<HealthMedicine>().eq("archive_number",healthMedicine.getArchiveNumber()))!=null){
            return Result.failure(ResultCode.DATA_STATUS_DELETE);
        }
        return Result.success(healthMedicineMapper.insert(healthMedicine));
    }

    @Override
    public Result getHealthMedicineByArchiveNumber(String archiveNumber) {
        HealthMedicine healthMedicine = healthMedicineMapper.selectOne(new QueryWrapper<HealthMedicine>().eq("archive_number", archiveNumber));
        if (healthMedicine!=null){
            return Result.success(healthMedicine);
        }
        return Result.failure(ResultCode.DATA_STATUS_DELETE);
    }
}




