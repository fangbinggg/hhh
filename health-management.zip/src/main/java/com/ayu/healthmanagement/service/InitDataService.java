package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.utils.Result;

import javax.servlet.http.HttpServletRequest;

public interface InitDataService {
    /**
     * 获取各项指标平均值
     * @param request
     * @return
     */
    Result getInitAverageValue(HttpServletRequest request);

    Result getIllness();

    Result getInitByArchiveNumber(String archiveNumber);

}
