package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.dto.PageDto;
import com.ayu.healthmanagement.mapper.HealthUserMapper;
import com.ayu.healthmanagement.pojo.HealthUser;
import com.ayu.healthmanagement.utils.Result;
import com.ayu.healthmanagement.utils.ResultCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ayu.healthmanagement.pojo.HealthAppointment;
import com.ayu.healthmanagement.service.HealthAppointmentService;
import com.ayu.healthmanagement.mapper.HealthAppointmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 */
@Service
public class HealthAppointmentServiceImpl extends ServiceImpl<HealthAppointmentMapper, HealthAppointment>
    implements HealthAppointmentService{

    @Autowired
    private HealthUserMapper healthUserMapper;

    @Autowired
    private HealthAppointmentMapper healthAppointmentMapper;

    @Override
    public Result noCheckAppointment(Integer id) {
        HealthAppointment healthAppointment = healthAppointmentMapper.selectById(id);
        healthAppointment.setStatus("2");
        return Result.success(healthAppointmentMapper.updateById(healthAppointment));
    }

    @Override
    public Result checkAppointment(Integer id) {
        //生成预约编号
        String number="AY"+System.currentTimeMillis();
        HealthAppointment healthAppointment = healthAppointmentMapper.selectById(id);
        healthAppointment.setStatus("1");
        healthAppointment.setAppointmentNumber(number);
        return Result.success(healthAppointmentMapper.updateById(healthAppointment));
    }

    @Override
    public Result delAppointment(Integer id) {
        return Result.success(healthAppointmentMapper.deleteById(id));
    }

    @Override
    public Result insertAppointment(HealthAppointment healthAppointment) {
        //查询是否有未处理的预约记录
        List<HealthAppointment> healthAppointments = healthAppointmentMapper.selectList(new QueryWrapper<HealthAppointment>()
                .eq("user_id", healthAppointment.getUserId())
                .eq("status", "0")
                .or()
                .eq("user_id", healthAppointment.getUserId())
                .eq("status","1"));

        if (healthAppointments.size()!=0){
            //50003
            return Result.failure(ResultCode.DATA_ALREADY_EXISTED);
        }
        return Result.success(healthAppointmentMapper.insert(healthAppointment));
    }

    @Override
    public Result getAppointmentList(Integer userId,String userPhone, Integer pageNum, Integer pageSize) {
        HealthUser healthUser = healthUserMapper.selectById(userId);
        List<HealthAppointment> appointmentList = healthAppointmentMapper.getAppointmentList(null,userPhone, (pageNum - 1) * pageSize, pageSize);
        int size = healthAppointmentMapper.getAppointmentList(null,userPhone, null, null).size();
        if (healthUser.getUserRole().equals("U")){
            appointmentList = healthAppointmentMapper.getAppointmentList(userId,userPhone, (pageNum - 1) * pageSize, pageSize);
            size = healthAppointmentMapper.getAppointmentList(userId,userPhone, null, null).size();
        }
        return Result.success(new PageDto(pageNum,pageSize,size,appointmentList));
    }
}




