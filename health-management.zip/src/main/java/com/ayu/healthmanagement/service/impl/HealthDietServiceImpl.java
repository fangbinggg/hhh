package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.dto.PageDto;
import com.ayu.healthmanagement.utils.Result;
import com.ayu.healthmanagement.utils.ResultCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ayu.healthmanagement.pojo.HealthDiet;
import com.ayu.healthmanagement.service.HealthDietService;
import com.ayu.healthmanagement.mapper.HealthDietMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 */
@Service
public class HealthDietServiceImpl extends ServiceImpl<HealthDietMapper, HealthDiet>
    implements HealthDietService{

    @Autowired
    private HealthDietMapper healthDietMapper;

    @Override
    public Result getHealthDiets(String dietName, Integer pageNum, Integer pageSize) {
        List<HealthDiet> healthDiets = healthDietMapper.getHealthDiets(dietName, (pageNum - 1) * pageSize, pageSize);
        int size = healthDietMapper.getHealthDiets(dietName, null, null).size();
        return Result.success(new PageDto(pageNum,pageSize,size,healthDiets));
    }

    @Override
    public Result delHealthDiet(Integer id) {
        return Result.success(healthDietMapper.deleteById(id));
    }

    @Override
    public Result updateHealthDiet(HealthDiet healthDiet) {
        return Result.success(healthDietMapper.updateById(healthDiet));
    }

    @Override
    public Result insertHealthDiet(HealthDiet healthDiet) {
        //若果该档案已存在饮食方案推荐，将不允许再次添加
        HealthDiet diet = healthDietMapper.selectOne(new QueryWrapper<HealthDiet>().eq("archive_number", healthDiet.getArchiveNumber()));
        if (diet!=null){
            return Result.failure(ResultCode.DATA_STATUS_DELETE);
        }
        return Result.success(healthDietMapper.insert(healthDiet));
    }

    @Override
    public Result getHealthDietsByArchiveNumber(String archiveNumber) {
        HealthDiet healthDiet = healthDietMapper.selectOne(new QueryWrapper<HealthDiet>().eq("archive_number", archiveNumber));
        if (healthDiet!=null){
            return Result.success(healthDiet);
        }
        return Result.failure(ResultCode.DATA_STATUS_DELETE);
    }
}




