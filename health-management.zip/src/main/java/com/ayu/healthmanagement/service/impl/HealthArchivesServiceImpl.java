package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.dto.ArchivesAndUserDto;
import com.ayu.healthmanagement.dto.PageDto;
import com.ayu.healthmanagement.utils.ExcelUtil;
import com.ayu.healthmanagement.utils.Result;
import com.ayu.healthmanagement.utils.ResultCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.service.HealthArchivesService;
import com.ayu.healthmanagement.mapper.HealthArchivesMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;

/**
 *
 */
@Service
public class HealthArchivesServiceImpl extends ServiceImpl<HealthArchivesMapper, HealthArchives>
    implements HealthArchivesService{

    @Autowired
    private HealthArchivesMapper healthArchivesMapper;

    @Override
    public Result getArchivesByUserId(Integer userId) {
        ArchivesAndUserDto archives = healthArchivesMapper.getArchivesByUserId(userId);
        return Result.success(archives);
    }

    @Override
    public Result getArchives(Integer groupId,String userPhone, String idCard, Integer pageNum, Integer pageSize) {
        List<ArchivesAndUserDto> archives = healthArchivesMapper.getArchives(groupId,userPhone, idCard, (pageNum - 1) * pageSize, pageSize);
        int size = healthArchivesMapper.getArchives(groupId,userPhone, idCard, null, null).size();
        return Result.success(new PageDto(pageNum,pageSize,size,archives));
    }

    @Override
    public Result updateArchives(HealthArchives healthArchives) {
        return Result.success(healthArchivesMapper.updateById(healthArchives));
    }

    @Override
    public Result insertArchives(HealthArchives healthArchives) {
        //验重
        HealthArchives archives = healthArchivesMapper.selectOne(new QueryWrapper<HealthArchives>().eq("user_id", healthArchives.getUserId()));
        if (archives!=null){
            return Result.failure(ResultCode.DATA_ALREADY_EXISTED);
        }
        //生成档案编号
        String archivesNumber="AN"+System.currentTimeMillis();
        healthArchives.setArchiveNumber(archivesNumber);
        return Result.success(healthArchivesMapper.insert(healthArchives));
    }

    @Override
    public Result delArchives(Integer id) {
        int i = healthArchivesMapper.deleteById(id);
        if (i==1){
            return Result.success();
        }
        return Result.failure(ResultCode.DATA_STATUS_DELETE);
    }

    @Override
    public Result getArchivesByNumber(String archiveNumber) {
        ArchivesAndUserDto archives = healthArchivesMapper.getArchivesByNumber(archiveNumber);
        if (archives!=null){
            return Result.success(archives);
        }
        return Result.failure(ResultCode.DATA_STATUS_DELETE);
    }

    @Override
    public void downLoad(Long[] ids, HttpServletResponse response) {
        List<HealthArchives> healthArchives = healthArchivesMapper.selectBatchIds(Arrays.asList(ids));
        healthArchives.forEach(healthArchives1 -> {
            healthArchives1.setGender(healthArchives1.getGender().equalsIgnoreCase("M")?"男":"女");
            healthArchives1.setLiver(healthArchives1.getLiver().equals("0")?"是":"否");
            healthArchives1.setKidney(healthArchives1.getKidney().equals("0")?"是":"否");
            healthArchives1.setGallbladder(healthArchives1.getGallbladder().equals("0")?"是":"否");
            healthArchives1.setSpleen(healthArchives1.getSpleen().equals("0")?"是":"否");
            healthArchives1.setStomach(healthArchives1.getStomach().equals("0")?"是":"否");
            healthArchives1.setSmell(healthArchives1.getSmell().equals("0")?"是":"否");
            healthArchives1.setGustatorysensation(healthArchives1.getGustatorysensation().equals("0")?"是":"否");
            healthArchives1.setTactilesensation(healthArchives1.getTactilesensation().equals("0")?"是":"否");
            healthArchives1.setVision(healthArchives1.getVision().equals("0")?"是":"否");
        });
        ExcelUtil.download(response,healthArchives,HealthArchives.class);
    }
}




