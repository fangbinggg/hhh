package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthJkpg;
import com.baomidou.mybatisplus.extension.service.IService;

public interface HealthJkpgService extends IService<HealthJkpg> {
}
