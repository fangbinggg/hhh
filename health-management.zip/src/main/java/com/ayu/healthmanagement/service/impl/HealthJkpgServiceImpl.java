package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.mapper.HealthJkpgMapper;
import com.ayu.healthmanagement.pojo.HealthJkpg;
import com.ayu.healthmanagement.service.HealthJkpgService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class HealthJkpgServiceImpl extends ServiceImpl<HealthJkpgMapper, HealthJkpg> implements HealthJkpgService {
}
