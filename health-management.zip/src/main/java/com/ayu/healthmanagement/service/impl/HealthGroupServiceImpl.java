package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.mapper.HealthArchivesMapper;
import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.utils.Result;
import com.ayu.healthmanagement.utils.ResultCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ayu.healthmanagement.pojo.HealthGroup;
import com.ayu.healthmanagement.service.HealthGroupService;
import com.ayu.healthmanagement.mapper.HealthGroupMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 */
@Service
public class HealthGroupServiceImpl extends ServiceImpl<HealthGroupMapper, HealthGroup>
    implements HealthGroupService{

    @Autowired
    private HealthArchivesMapper healthArchivesMapper;

    @Autowired
    private HealthGroupMapper healthGroupMapper;

    @Override
    public Result delHealthGroup(Integer id) {
        //判断改组下是否存在档案，存在不允许删除
        List<HealthArchives> healthArchives = healthArchivesMapper.selectList(new QueryWrapper<HealthArchives>().eq("group_id", id));
        if (healthArchives.size()!=0){
            return Result.failure(ResultCode.DATA_STATUS_DELETE);
        }
        return Result.success(healthGroupMapper.deleteById(id));
    }

    @Override
    public Result getHealthGroups(String groupName) {
        return Result.success(healthGroupMapper.selectList(new QueryWrapper<HealthGroup>().like("group_name",groupName)));
    }

    @Override
    public Result updateHealthGroup(HealthGroup healthGroup) {
        return Result.success(healthGroupMapper.updateById(healthGroup));
    }

    @Override
    public Result insertHealthGroup(HealthGroup healthGroup) {
        return Result.success(healthGroupMapper.insert(healthGroup));
    }
}




