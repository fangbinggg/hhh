package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthTaocan;
import com.baomidou.mybatisplus.extension.service.IService;

public interface HealthTaocanService extends IService<HealthTaocan> {
}
