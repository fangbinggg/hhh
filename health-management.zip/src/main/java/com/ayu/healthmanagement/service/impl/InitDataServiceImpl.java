package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.mapper.HealthArchivesMapper;
import com.ayu.healthmanagement.mapper.HealthUserMapper;
import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.pojo.HealthUser;
import com.ayu.healthmanagement.service.InitDataService;
import com.ayu.healthmanagement.utils.JwtUtils;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

@Service
public class InitDataServiceImpl implements InitDataService {

    @Data
    public class Illness{
        private Integer value;
        private String name;

        public Illness(Integer value, String name) {
            this.value = value;
            this.name = name;
        }
    }

    @Autowired
    private HealthUserMapper healthUserMapper;

    @Autowired
    private HealthArchivesMapper healthArchivesMapper;

    @Override
    public Result getInitAverageValue(HttpServletRequest request) {
        String token = request.getHeader("token");
        Integer id = Integer.parseInt(JwtUtils.getId(token));
        System.out.println("用户id =》"+id);
        HealthUser healthUser = healthUserMapper.selectById(id);
        HealthArchives archives = healthArchivesMapper.selectOne(new QueryWrapper<HealthArchives>().eq("user_id", healthUser.getId()));
        if (archives!=null && !healthUser.getUserRole().equals("A")){
            ArrayList<Double> list = new ArrayList<>();
            list.add(archives.getAge().doubleValue());
            list.add(archives.getHeight().doubleValue());
            list.add(archives.getWeight().doubleValue());
            list.add(Double.parseDouble(archives.getBloodPressure()));
            list.add(Double.parseDouble(archives.getBloodSugar()));
            list.add(Double.parseDouble(archives.getHeartRate()));
            return Result.success(list);
        }
        double ageAverageValue = healthArchivesMapper.getAgeAverageValue();
        double heightAverageValue = healthArchivesMapper.getHeightAverageValue();
        double weightAverageValue = healthArchivesMapper.getWeightAverageValue();
        double bloodPressureAverageValue = healthArchivesMapper.getBloodPressureAverageValue();
        double bloodSugarAverageValue = healthArchivesMapper.getBloodSugarAverageValue();
        double heartRateAverageValue = healthArchivesMapper.getHeartRateAverageValue()+1;
        ArrayList<Double> list = new ArrayList<>();
        list.add(ageAverageValue);
        list.add(heightAverageValue);
        list.add(weightAverageValue);
        list.add(bloodPressureAverageValue);
        list.add(bloodSugarAverageValue);
        list.add(heartRateAverageValue);
        System.out.println(ageAverageValue);
        return Result.success(list);
    }

    @Override
    public Result getIllness() {
        ArrayList<Illness> illnesses = new ArrayList<>();
        List<HealthArchives> healthArchives = healthArchivesMapper.selectList(new QueryWrapper<>());
        int a1=0;//健康
        int a2=0;//亚健康
        int a3=0;//危险
        int a4=0;
        for (HealthArchives healthArchive : healthArchives) {
            if (Integer.valueOf(healthArchive.getBloodPressure())>140 || Integer.valueOf(healthArchive.getBloodPressure())<90){
                a3++;
            }else {
                a1++;
            }
            if (Integer.valueOf(healthArchive.getBloodSugar())>4 && Integer.valueOf(healthArchive.getBloodSugar())<6){
                a1++;
            }else {
                a2++;
            }
            if (Integer.valueOf(healthArchive.getHeartRate())>60 && Integer.valueOf(healthArchive.getHeartRate())<100){
                a1++;
            }else if (Integer.valueOf(healthArchive.getHeartRate())>100 && Integer.valueOf(healthArchive.getHeartRate())<150){
                a2++;
            }else {
                a3++;
            }
            if (healthArchive.getWeight()>50 && healthArchive.getWeight()<200){
                a1++;
            }else {
                a4++;
            }
        }
        illnesses.add(new Illness(a1,"健康"));
        illnesses.add(new Illness(a2,"亚健康"));
        illnesses.add(new Illness(a3,"患病"));
        illnesses.add(new Illness(a4,"预患病"));
        return Result.success(illnesses);
    }

    @Override
    public Result getInitByArchiveNumber(String archiveNumber) {
        HashMap<String, Object> map = new HashMap<>();
        HealthArchives healthArchives = healthArchivesMapper.selectOne(new QueryWrapper<HealthArchives>().eq("archive_number", archiveNumber));
        ArrayList<Integer> list = new ArrayList<>();
        list.add(healthArchives.getAge()*100);//年龄
        list.add(healthArchives.getWeight()*100);//体重
        list.add(healthArchives.getHeight()*100);//身高
        list.add(Integer.parseInt(healthArchives.getHeartRate())*100);//心率
        list.add(Integer.parseInt(healthArchives.getBloodSugar())*100);//血糖
        list.add(Integer.parseInt(healthArchives.getBloodPressure())*100);//血压
        ArrayList<Integer> list1 = new ArrayList<>();
        Random random = new Random();
        list1.add(random.nextInt(3000) + 1000);
        list1.add(random.nextInt(3000) + 1000);
        list1.add(random.nextInt(3000) + 1000);
        list1.add(random.nextInt(3000) + 1000);
        list1.add(random.nextInt(3000) + 1000);
        list1.add(random.nextInt(3000) + 1000);
        map.put("list1",list);
        map.put("list2",list1);
        map.put("healthArchives",healthArchives);
        return Result.success(map);
    }
}
