package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthGroup;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface HealthGroupService extends IService<HealthGroup> {

    /**
     *
     * @param id
     * @return
     */
    Result delHealthGroup(Integer id);

    /**
     *
     * @param groupName
     * @return
     */
    Result getHealthGroups(String groupName);

    /**
     *
     * @param healthGroup
     * @return
     */
    Result updateHealthGroup(HealthGroup healthGroup);

    /**
     *
     * @param healthGroup
     * @return
     */
    Result insertHealthGroup(HealthGroup healthGroup);

}
