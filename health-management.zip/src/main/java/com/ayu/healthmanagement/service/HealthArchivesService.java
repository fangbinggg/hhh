package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthArchives;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;

import javax.servlet.http.HttpServletResponse;

/**
 *
 */
public interface HealthArchivesService extends IService<HealthArchives> {

    /**
     * 通过用户id查询档案
     * @param userId
     * @return
     */
    Result getArchivesByUserId(Integer userId);

    /**
     * 查询档案（分页查询）
     * @param userPhone
     * @param idCard
     * @param pageNum
     * @param pageSize
     * @return
     */
    Result getArchives(Integer groupId,String userPhone,String idCard,Integer pageNum,Integer pageSize);

    /**
     * 更新档案
     * @param healthArchives
     * @return
     */
    Result updateArchives(HealthArchives healthArchives);
    /**
     * 录入档案
     * @param healthArchives
     * @return
     */
    Result insertArchives(HealthArchives healthArchives);

    /**
     * 删除档案
     * @param id
     * @return
     */
    Result delArchives(Integer id);

    /**
     *
     * @param archiveNumber
     * @return
     */
    Result getArchivesByNumber(String archiveNumber);

    /**
     * 导出档案
     * @param ids
     * @param response
     */
    void downLoad(Long[] ids, HttpServletResponse response);
}
