package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthDiet;
import com.ayu.healthmanagement.pojo.HealthMedicine;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface HealthMedicineService extends IService<HealthMedicine> {
    /**
     *
     * @param medicineName
     * @param pageNum
     * @param pageSize
     * @return
     */
    Result getHealthMedicine(String medicineName, Integer pageNum, Integer pageSize);

    /**
     * 删除饮食方案
     * @param id
     * @return
     */
    Result delHealthMedicine(Integer id);

    /**
     *
     * @param healthMedicine
     * @return
     */
    Result updateHealthMedicine(HealthMedicine healthMedicine);

    /**
     *
     * @param healthMedicine
     * @return
     */
    Result insertHealthMedicine(HealthMedicine healthMedicine);

    /**
     * 通过档案编号获取用药推荐
     * @param archiveNumber
     * @return
     */
    Result getHealthMedicineByArchiveNumber(String archiveNumber);
}
