package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.dto.PageDto;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ayu.healthmanagement.pojo.HealthRecord;
import com.ayu.healthmanagement.service.HealthRecordService;
import com.ayu.healthmanagement.mapper.HealthRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 */
@Service
public class HealthRecordServiceImpl extends ServiceImpl<HealthRecordMapper, HealthRecord>
    implements HealthRecordService{

    @Autowired
    private HealthRecordMapper healthRecordMapper;

    @Override
    public Result getHealthRecords(String beginTime, String endTime, Integer pageNum, Integer pageSize) {
        System.out.println(beginTime+"==="+endTime);
        List<HealthRecord> healthRecords = healthRecordMapper.getHealthRecords(beginTime, endTime, (pageNum - 1) * pageSize, pageSize);
        int size = healthRecordMapper.getHealthRecords(beginTime, endTime, null, null).size();
        return Result.success(new PageDto(pageNum,pageSize,size,healthRecords));
    }

    @Override
    public Result delHealthRecord(Integer id) {
        return Result.success(healthRecordMapper.deleteById(id));
    }

    @Override
    public Result insertHealthRecord(HealthRecord healthRecord) {
        return Result.success(healthRecordMapper.insert(healthRecord));
    }
}




