package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthJkyj;
import com.baomidou.mybatisplus.extension.service.IService;

public interface HealthJkyjService extends IService<HealthJkyj> {
}
