package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.dto.UserDto;
import com.ayu.healthmanagement.pojo.HealthUser;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 *
 */
public interface HealthUserService extends IService<HealthUser> {

    /**
     * 注册
     * @param healthUser
     * @return
     */
    Result register(HealthUser healthUser);

    /**
     * 登录
     * @param healthUser
     * @return
     */
    Result login(HealthUser healthUser);

    /**
     * 获取用户信息
     * @param userId
     * @return
     */
    Result getUserById(Integer userId);

    /**
     * 获取用户信息
     * @param userDto
     * @return
     */
    Result getSysUserList(UserDto userDto);

    /**
     *
     * @param healthUser
     * @return
     */
    Result updateUser(HealthUser healthUser);

    Result delUser(Integer[] ids);

    Result resetPassword(Integer userId, String password);

    Result updatePassword(Integer userId,String oldPassword, String newPassword);

    Result updateImgUrl(Integer id, String imgUrl);

    Result getUserByUserPhone(String userPhone);

    /**
     * 导出
     * @param ids
     * @param response
     */
    void downLoad(Long[] ids, HttpServletResponse response);

    /**
     * 导入用户
     * @param file
     * @return
     */
    int importUsers(MultipartFile file);

}
