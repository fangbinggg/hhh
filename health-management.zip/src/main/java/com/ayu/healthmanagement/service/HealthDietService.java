package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthDiet;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface HealthDietService extends IService<HealthDiet> {

    /**
     *
     * @param dietName
     * @param pageNum
     * @param pageSize
     * @return
     */
    Result getHealthDiets(String dietName,Integer pageNum,Integer pageSize);

    /**
     * 删除饮食方案
     * @param id
     * @return
     */
    Result delHealthDiet(Integer id);

    /**
     *
     * @param healthDiet
     * @return
     */
    Result updateHealthDiet(HealthDiet healthDiet);

    /**
     *
     * @param healthDiet
     * @return
     */
    Result insertHealthDiet(HealthDiet healthDiet);

    /**
     * 通过档案编号获取饮食方案
     * @param archiveNumber
     * @return
     */
    Result getHealthDietsByArchiveNumber(String archiveNumber);
}
