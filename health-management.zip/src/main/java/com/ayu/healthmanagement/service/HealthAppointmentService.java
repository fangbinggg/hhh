package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthAppointment;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface HealthAppointmentService extends IService<HealthAppointment> {

    /**
     * 不同意预约申请
     * @param id
     * @return
     */
    Result noCheckAppointment(Integer id);

    /**
     * 管理员同意预约申请
     * @param id
     * @return
     */
    Result checkAppointment(Integer id);

    /**
     * 取消预约
     * @param id
     * @return
     */
    Result delAppointment(Integer id);

    /**
     * 体检预约
     * @param healthAppointment
     * @return
     */
    Result insertAppointment(HealthAppointment healthAppointment);

    /**
     * 查询预约记录
     * @param userPhone
     * @param pageNum
     * @param pageSize
     * @return
     */
    Result getAppointmentList(Integer userId,String userPhone,Integer pageNum,Integer pageSize);
}
