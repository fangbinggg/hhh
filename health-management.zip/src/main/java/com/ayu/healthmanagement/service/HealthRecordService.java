package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthRecord;
import com.ayu.healthmanagement.utils.Result;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface HealthRecordService extends IService<HealthRecord> {

    /**
     *
     * @param beginTime
     * @param endTime
     * @param pageNum
     * @param pageSize
     * @return
     */
    Result getHealthRecords(String beginTime,String endTime,Integer pageNum,Integer pageSize);

    /**
     * 删除日志
     * @param id
     * @return
     */
    Result delHealthRecord(Integer id);

    /**
     * 添加日志
     * @param healthRecord
     * @return
     */
    Result insertHealthRecord(HealthRecord healthRecord);

}
