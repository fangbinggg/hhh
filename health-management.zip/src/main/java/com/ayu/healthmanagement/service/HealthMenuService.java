package com.ayu.healthmanagement.service;

import com.ayu.healthmanagement.pojo.HealthMenu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 *
 */
public interface HealthMenuService extends IService<HealthMenu> {
    /**
     * 获取菜单
     * @return
     */
    List<HealthMenu> getMenus(Integer userId);

}
