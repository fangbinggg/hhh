package com.ayu.healthmanagement.service.impl;

import com.ayu.healthmanagement.mapper.HealthTaocanMapper;
import com.ayu.healthmanagement.pojo.HealthTaocan;
import com.ayu.healthmanagement.service.HealthTaocanService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class HealthTaocanServiceImpl extends ServiceImpl<HealthTaocanMapper, HealthTaocan> implements HealthTaocanService {
}
