package com.ayu.healthmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
